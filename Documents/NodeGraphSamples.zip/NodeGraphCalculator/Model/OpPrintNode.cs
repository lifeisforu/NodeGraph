﻿using NodeGraph;
using NodeGraph.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace NodeGraphCalculator.Model
{
	[Node()]
	[NodeFlowPort( "Input", "", true )]
	[NodeFlowPort( "Output", "", false )]
	public class OpPrintNode : CalculatorNodeBase
	{
		#region Constructor

		public OpPrintNode( Guid guid, FlowChart flowChart ) : base( guid, flowChart, CalculatorNodeType.OpPrint )
		{
			Header = "Print";
			HeaderBackgroundColor = Brushes.DarkBlue;
			AllowEditingHeader = false;
		}

		#endregion // Constructor

		#region Callbacks

		public override void OnCreate()
		{
			NodeGraphManager.CreateNodePropertyPort( false, Guid.NewGuid(), this, true, typeof( object ), null,
				"Object", false, null, "Object" );

			base.OnCreate();
		}

		public override void OnPreExecute( Connector prevConnector )
		{
			base.OnPreExecute( prevConnector );

			NodePropertyPort portObject = NodeGraphManager.FindNodePropertyPort( this, "Object" );
			if( 1 == portObject.Connectors.Count )
			{
				Connector connector = portObject.Connectors[ 0 ];
				NodePropertyPort port = connector.StartPort as NodePropertyPort;
				portObject.Value = port.Value;
			}
		}

		public override void OnExecute( Connector prevConnector )
		{
			base.OnExecute( prevConnector );

			NodePropertyPort portObject = NodeGraphManager.FindNodePropertyPort( this, "Object" );
			string result = string.Empty;
			if( null != portObject.Value )
			{
				result = string.Format( "{0}", portObject.Value.ToString() );
				NodeGraphManager.AddScreenLog( Owner, result );
			}
		}

		public override void OnPostExecute( Connector prevConnector )
		{
			base.OnPostExecute( prevConnector );

			NodeFlowPort port = OutputFlowPorts[ 0 ]; // there is always only one flow port.
			Connector connector = ( 1 == port.Connectors.Count ) ? port.Connectors[ 0 ] : null; // there is always only one connector if any.
			if( null != connector )
			{
				connector.OnPreExecute();
				connector.OnExecute();
				connector.OnPostExecute();
			}
		}

		#endregion // Callbacks
	}
}
