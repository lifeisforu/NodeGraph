﻿using NodeGraph;
using NodeGraph.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace NodeGraphCalculator.Model
{
	[Node()]
	[NodeFlowPort( "Exec", "Exec", true )]
	[NodeFlowPort( "Output", "", false )]
	public class OpMakeArrayNode : CalculatorNodeBase
	{
		#region Constructor

		public OpMakeArrayNode( Guid guid, FlowChart flowChart ) : base( guid, flowChart, CalculatorNodeType.OpMakeArray )
		{
			Header = "MakeArray";
			HeaderBackgroundColor = Brushes.DarkBlue;
			AllowEditingHeader = false;
		}

		#endregion // Constructor

		#region Callbacks

		public override void OnCreate()
		{
			NodeGraphManager.CreateNodePropertyPort( false, Guid.NewGuid(), this, true, typeof( object ), null,
				"Objects", false, null, "Objects( multiple input )", true );

			NodeGraphManager.CreateNodePropertyPort( false, Guid.NewGuid(), this, false, typeof( ObservableCollection<object> ), new ObservableCollection<object>(),
				"Array", false, null, "Array" );

			base.OnCreate();
		}

		public override void OnPreExecute( Connector prevConnector )
		{
			base.OnPreExecute( prevConnector );
		}

		public override void OnExecute( Connector prevConnector )
		{
			base.OnExecute( prevConnector );

			NodePropertyPort portOutputArray = NodeGraphManager.FindNodePropertyPort( this, "Array" );
			NodePropertyPort portObjects = NodeGraphManager.FindNodePropertyPort( this, "Objects" );

			ObservableCollection<object> array = portOutputArray.Value as ObservableCollection<object>;
			array.Clear();
			if( 0 < portObjects.Connectors.Count )
			{
				foreach( var connector in portObjects.Connectors )
				{
					NodePropertyPort startPort = connector.StartPort as NodePropertyPort;
					array.Add( startPort.Value );
				}
			}
		}

		public override void OnPostExecute( Connector prevConnector )
		{
			base.OnPostExecute( prevConnector );

			NodeFlowPort port = NodeGraphManager.FindNodeFlowPort( this, "Output" );
			Connector connector = ( 1 == port.Connectors.Count ) ? port.Connectors[ 0 ] : null; // there is always only one connector if any.
			if( null != connector )
			{
				connector.OnPreExecute();
				connector.OnExecute();
				connector.OnPostExecute();
			}
		}

		#endregion // Callbacks
	}
}
